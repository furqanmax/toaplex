<!DOCTYPE html>
<html>
<head>
  <title>Email</title>
</head>
<body>
Name:{{$user['name']}}<br>
Email:{{$user['email']}}<br>
MobileNo:{{$user['mobile']}}<br>
Message:{{$user['message']}}<br>
</body>
</html>