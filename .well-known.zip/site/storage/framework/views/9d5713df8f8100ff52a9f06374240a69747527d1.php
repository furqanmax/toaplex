<?php $__env->startSection('content'); ?>
    <!--====banner====-->
    <section class="banner">
        <div class="container py-3">
            <div class="baner-text py-5">
                <div class="row py-5 my-5">
                    <div class="col-md-8">
                        <h1 class="h1 h1-responsive">
                            Get advanced mobile and<br> web applications using latest<br> technologies.
                        </h1>
                        <p>
                            We consult, design & engineer successful web, mobile & custom software solutions, that fuel
                            innovation & increase business efficiency!
                        </p>
                        <div class="">
                            <a href="" class="btn btn-border">Contact us</a>
                            <a href="" class="btn btn-custom">Find out how we can help you</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====banner====-->
    <!--========about us=================--->
    <section class="about-us  ">
        <div class="container py-5">
            <div class="row py-5">
                <div class="col-md-6">
                    <img src="<?php echo e(asset('svg/about.png')); ?>" class="img img-fluid" alt="">
                </div>
                <div class="col-md-6">
                    <h1 class="h1 h1-responsive pb-2">
                        You Want a Partner,<br> Not a Developer
                    </h1>
                    <p class="pb-2">
                        At Space-O, we do have an abundance mindset. The more our clients succeed, the more we succeed.
                        Sure, we could take the easy way out, and bill out large funds to businesses who don’t know the
                        software design and development process. But we believe that building our client’s knowledge and
                        expertise will pay off way more in the long run. We are not here to be hired; we are here to
                        partner.
                    </p>
                    <p>
                        Our skilled strategists, designers, and developers are here to take your project from ideation to
                        publication. Being a leading software development company in Canada, our team is committed to
                        developing mobile app and web-based software solutions that keep your users hooked straight into it.

                    </p>
                </div>
            </div>
        </div>

    </section>
    <!--========about us=================--->
    <!--==============core services============-->
    <section class="mt-5 pt-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 text-right h-bg ">
                    <h3 class="text-white mb-0 ">Core</h3>
                </div>
                <div class="col-md-6 m-0 p-0">
                    <h3 class="mb-0 ">Services</h3>
                </div>
            </div>
        </div>

    </section>
    <section class="mb-5 " style="background: #FAFAFA">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4 col-md-6  ">
                    <!-- Card -->
                    <div class="card py-4 service-card">

                        <!-- Card content -->
                        <div class="card-body" style="background-image: url('svg/service1.png')">
                            <!-- Card image -->
                            <img src="<?php echo e(asset('svg/app.png')); ?>" width="24" alt="">
                            <h4 class="service-card-title py-4 mb-0">Web<br>
                                Development</h4>
                            <!-- Title -->
                            <!-- Text -->
                            <p class="service-card-content pt-0 mt-0">For 10+ years now, we’ve mastered the top web
                                technologies to deliver projects that have raked in investments. A trusted market leader in
                                developing high performing web fronts for every business.</p>
                            <!-- Button -->
                            <a href="#" class="black-text pt-4" style="letter-spacing: 0.5rem;">EXPLORE <i
                                    class="fas fa-angle-right"></i></a>

                        </div>

                    </div>
                    <!-- Card -->

                </div>
            </div>
            <div class="text-center">
                <a href="" class="btn btn-custom mt-5">Contact us</a>
            </div>
        </div>
    </section>
    <!--==============core services---============-->
    <!--==============custom software---============-->
    <section class="about-us">
        <div class="container">
            <div class="software-heading">
                <h3 class="h3 h3-responsive pb-0 mb-0 text-center">
                    Custome Software Development
                </h3>
                <p class="text-center font-32 pt-0 mt-0">
                    We create software solutions to transform internal operations
                </p>
            </div>
            <div class="software-boxes py-4">
                <div class="row">
                    <div class="col-md-4">
                        <!-- Card -->
                        <div class="card card-cascade wider reverse">

                            <!-- Card image -->
                            <div class="view view-cascade overlay">
                                <img class="card-img-top" src="<?php echo e(asset('svg/crm.png')); ?>" alt="">
                                <a href="#!">
                                    <div class="mask rgba-white-slight"></div>
                                </a>
                            </div>

                            <!-- Card content -->
                            <div class="card-body card-body-cascade py-4">

                                <!-- Title -->
                                <h4 class="font-weight-bold service-card-title">CRM</h4>
                                <!-- Subtitle -->
                                <!-- Text -->
                                <p class="card-text service-card-content py-2">We give the utmost importance to understand
                                    and
                                    document client’s inputs, design, and branding preferences.
                                </p>
                                <div class="">
                                    <a href="" class="btn btn-border font-weight-bold">View more</a>
                                </div>
                            </div>

                        </div>
                        <!-- Card -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--==============custom software---============-->
    <!--Portfolio-->
    <section class="mt-5 pt-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 text-right h-bg ">
                    <h3 class="text-white mb-0 ">Portfolio that </h3>
                </div>
                <div class="col-md-6 m-0 p-0">
                    <h3 class="mb-0 ">speak!</h3>
                </div>
            </div>
        </div>

    </section>
    <section>
        <div class="portfolio">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link tabs-link active p-0 m-0" id="portfolio-tab" data-toggle="tab" href="#portfolio"
                        role="tab" aria-controls="portfolio" aria-selected="true">
                        <img src="<?php echo e(asset('svg/tsm.png')); ?>" width="250" alt="">
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link tabs-link m-0 p-0" id="portfolio2-tab" data-toggle="tab" href="#portfolio2"
                        role="tab" aria-controls="portfolio2" aria-selected="false">
                        <img src="<?php echo e(asset('svg/udial.png')); ?>" width="250" alt="">
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link tabs-link m-0 p-0" id="portfolio3-tab" data-toggle="tab" href="#portfolio3"
                        role="tab" aria-controls="portfolio3" aria-selected="false">
                        <img src="<?php echo e(asset('svg/ziroot.png')); ?>" width="250" alt="">
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link tabs-link m-0 p-0" id="portfolio5-tab" data-toggle="tab" href="#portfolio5"
                        role="tab" aria-controls="portfolio5" aria-selected="false">
                        <img src="<?php echo e(asset('svg/crc.png')); ?>" width="250" alt="">
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link tabs-link m-0 p-0" id="portfolio6-tab" data-toggle="tab" href="#portfolio6"
                        role="tab" aria-controls="portfolio6" aria-selected="false">
                        <img src="<?php echo e(asset('svg/latenightpizza.png')); ?>" width="250" alt="">
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link tabs-link m-0 p-0" id="portfolio4-tab" data-toggle="tab" href="#portfolio4"
                        role="tab" aria-controls="portfolio4" aria-selected="false">
                        <img src="<?php echo e(asset('svg/quick.png')); ?>" width="250" alt="">
                    </a>
                </li>

            </ul>
            <div class="tab-content py-5" style="background: #F0F4FF;" id="myTabContent">
                <div class="tab-pane fade show active" id="portfolio" role="tabpanel" aria-labelledby="portfolio-tab">
                    <div class="row px-5 m-0">
                        <div class="col-md-5">
                            <img src="<?php echo e(asset('svg/tsm.png')); ?>" class="img img-fluid" alt="">

                        </div>
                        <div class="col-md-6 ">
                            <h3>
                                The Space Mark
                            </h3>
                            <p class="py-3">
                                We give the utmost importance to understand and document client’s inputs, design, and
                                branding preferences. And clarify all the open-ended points to establish a precise and clear
                                idea about both clients’ and project’s goals. We work in a collaborative approach involving
                                key stakeholders to bring alignment in the business process.
                            </p>
                            <div class="">
                                <a href="" class="btn btn-custom text-uppercase">View Portfolio</a>
                                <a href="" class="btn btn-border text-uppercase">Contact us</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
    </section>
    <!--Portfolio-->
    <!--Our Process-->
    <section class="my-5 py-5">
        <div class="container">
            <h3 class=" text-center">
                Our process
            </h3>

            <div class="row py-5">
                <div class="col-md-3">
                    <ul class="nav nav-tabs tab-process" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link  nav-process py-3 active" id="home-tab" data-toggle="tab" href="#home"
                                role="tab" aria-controls="home" aria-selected="true">1. Discovery Workshop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-process py-3" id="profile-tab" data-toggle="tab" href="#profile"
                                role="tab" aria-controls="profile" aria-selected="false">2. Planning </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-process py-3" id="contact-tab" data-toggle="tab" href="#contact"
                                role="tab" aria-controls="contact" aria-selected="false">3. Designing </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-process py-3" id="contact-tab" data-toggle="tab" href="#contact"
                                role="tab" aria-controls="contact" aria-selected="false">4. Developing </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-process py-3" id="contact-tab" data-toggle="tab" href="#contact"
                                role="tab" aria-controls="contact" aria-selected="false">5. Testing </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-process py-3" id="contact-tab" data-toggle="tab" href="#contact"
                                role="tab" aria-controls="contact" aria-selected="false">6. Maintenance </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-9">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row">
                                <div class="col-md-4 m-0 p-0">
                                    <img src="<?php echo e(asset('svg/crm.png')); ?>" style="height: 100%;" class="img img-fluid"
                                        alt="">
                                </div>

                                <div class="col-md-8 m-0 p-0">
                                    <div class="card p-5 service-card">
                                        <h3 class="font-32">DISCOVERY WORKSHOP</h3>
                                        <p class="font-16 py-3">
                                            We give the utmost importance to understand and document client’s inputs,
                                            design, and branding preferences. And clarify all the open-ended points to
                                            establish a precise and clear idea about both clients’ and project’s goals. We
                                            work in a collaborative approach involving key stakeholders to bring alignment
                                            in the business process.
                                        </p>
                                        <div>
                                            <a href="" class="btn btn-border">Get in Touch</a>

                                        </div>

                                    </div>

                                </div>
                            </div>
                            <img src="<?php echo e(asset('svg/back-img.png')); ?>" class="layer-img d-none d-md-block d-lg-block" alt="">


                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">Food truck
                            fixie
                            locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. Exercitation +1 labore
                            velit,
                            blog sartorial PBR leggings next level wes anderson artisan four loko farm-to-table craft beer
                            twee.
                            Qui photo booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts ullamco ad vinyl
                            cillum
                            PBR. Homo nostrud organic, assumenda labore aesthetic magna delectus mollit. Keytar helvetica
                            VHS
                            salvia yr, vero magna velit sapiente labore stumptown. Vegan fanny pack odio cillum wes anderson
                            8-bit,
                            sustainable jean shorts beard ut DIY ethical culpa terry richardson biodiesel. Art party
                            scenester
                            stumptown, tumblr butcher vero sint qui sapiente accusamus tattooed echo park.</div>
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">Etsy mixtape
                            wayfarers, ethical wes anderson tofu before they sold out mcsweeney's organic lomo retro fanny
                            pack
                            lo-fi farm-to-table readymade. Messenger bag gentrify pitchfork tattooed craft beer, iphone
                            skateboard
                            locavore carles etsy salvia banksy hoodie helvetica. DIY synth PBR banksy irony. Leggings
                            gentrify
                            squid 8-bit cred pitchfork. Williamsburg banh mi whatever gluten-free, carles pitchfork
                            biodiesel fixie
                            etsy retro mlkshk vice blog. Scenester cred you probably haven't heard of them, vinyl craft beer
                            blog
                            stumptown. Pitchfork sustainable tofu synth chambray yr.</div>
                    </div>
                </div>
            </div>


        </div>
    </section>
    <!--Our Process-->
    <!--our experties-->
    <section class="my-5">
        <div class="container">
            <h3 class="text-center">
                Our experties
            </h3>
            <div class="experties py-5">
                <div class="row">
                    <div class="col-md-4">
                        <!-- Card -->
                        <div class="card" style="box-shadow: none">

                            <!-- Card image -->
                            <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Others/images/43.jpg"
                                alt="Card image cap">

                            <!-- Card content -->
                            <div class="card-body px-0">

                                <!-- Title -->
                                <h4 class="card-title font-22"><a>Shopping & E-Commerce</a></h4>
                                <!-- Text -->
                                <p class="card-text fon-14">We design & develop user-engaging eCommerce applications that
                                    improve ROI, increase brand exposure, and skyrocket your online business</p>
                                <!-- Button -->

                            </div>

                        </div>
                        <!-- Card -->
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!--our experties-->
    <!--Testimomial-->
    <section class="my-5">
        <div class="container">
            <h3 class="text-center pb-3">
                Testimonial
            </h3>
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <div>
                        <div class="row p-3 justify-content-md-center">
        
        
                          <div class="col-md-4">
                          <img src="<?php echo e(asset('svg/testi1.png')); ?>" class="" alt="">
                          </div>
                          <div class="col-md-6 mt-5 pt-4">
                            <!-- Card -->
                            <div class="card p-5 card-testimonilas text-black">
                              <!-- Card content -->
                              <div class="card-body">
        
                                <!-- Title -->
                                <h4 class="card-title font-weight-bold font-26">Clients Testimonials</h4>
                                <!-- Text -->
                                <p class="card-text py-2 font-16">“ Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet
                                  sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt
                                  nostrud amet.”</p>
                                <!-- Button -->
                                <p style="font-size: 13px!important;" class="font-weight-bold mb-0 pb-0">
                                  Courtney Henry
                                </p>
                                <p style="font-size: 13px!important;">
                                  PHP Developer
                                </p>
                              </div>
        
                            </div>
                            <!-- Card -->
                          </div>
                        </div>
                      </div>
                  </div>
                  
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
           
        </div>
    </section>
    <!--Testimomial-->
    <!--contact us-->
    <section class="my-5">
        <div class="container">
            <div class="contact">
                <div class="row">
                    <div class="col-md-5">
                        <h3 class="font-22">Have a project to discuss?<br>
                            Get in touch.</h3>
                        <form class="py-3">
                            <input type="text" id="name" class="form-control mb-4" placeholder="Full Name*">
                            <input type="email" id="email" class="form-control mb-4" placeholder="Email*">
                            <input type="text" id="mobile" class="form-control mb-4" placeholder="Phone Nuber*">
                            <select class="browser-default mb-4 custom-select">
                                <option selected>Select Project Type*</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            <select class="browser-default mb-4 custom-select">
                                <option selected>Approx Budge*</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            <div class="form-group">
                                <textarea class="form-control rounded-0" placeholder="Enter Messege Here" id="exampleFormControlTextarea1"
                                    rows="4"></textarea>
                            </div>
                            <button class="btn btn-custom btn-block" style="letter-spacing: 2px;">SUBMIT</button>
                        </form>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-6   contact-info">
                        <div class="">
                            <div class="card p-4 card-contact">
                                <div class="contact-content">
                                    <h3 class="font-32">Now is the Time to <br>
                                        Craft Brilliance Together</h3>   
                                        <p>
                                            Get in touch with our experts and let us turn your idea into an exceptional mobile app.
                                        </p>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>