
<?php $__env->startSection('content'); ?>
<section class="">
   <div class="container py-5">
        <h1 class="h1 h1-responsive  pb-5" style="font-size: 48px;">
                       Your vision plus our expertise<br>
equals new impulse to your growth
                            </h1>
                            
                            
                            <div class="row">
                                <div class="col-md-6">
                                <img src="http://toaplex.com/public/svg/latenightpizza.png" class="img img-fluid" alt="">  
                                
                                <p class="py-3 mb-0">
                                    Ecommerce
                                </p>
                                <h6 class="h6 h6-responsive">Late Night Pizza</h6>
                                </div>
                            </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>