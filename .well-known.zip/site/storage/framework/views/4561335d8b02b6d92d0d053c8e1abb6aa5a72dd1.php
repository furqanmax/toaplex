<!DOCTYPE html>
<html>
<head>
  <title>Email</title>
</head>
<body>
Name:<?php echo e($user['name']); ?><br>
Email:<?php echo e($user['email']); ?><br>
MobileNo:<?php echo e($user['mobile']); ?><br>
Message:<?php echo e($user['message']); ?><br>
</body>
</html>